package com.masai.dto;

public interface Lawyer {
	
	public int getId();

	public void setId(int id);

	public String getName();

	public void setName(String name);

	public String getEmail();

	public void setEmail(String email);

	public String getAddress();

	public void setAddress(String address);

	public int getExperience();

	public void setExperience(int experience);
}
